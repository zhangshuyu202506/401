"""
修复版科学计算模块
改进错误处理和函数实现
"""

import math

class ScientificCalculator:
    """修复版科学计算器核心类"""
    
    def __init__(self):
        self.angle_mode = 'degrees'
        self.history = []
    
    def set_angle_mode(self, mode):
        """设置角度模式"""
        if mode in ['degrees', 'radians']:
            self.angle_mode = mode
        else:
            raise ValueError("角度模式必须是 'degrees' 或 'radians'")
    
    def to_radians(self, angle):
        """转换为弧度"""
        try:
            angle = float(angle)
            if self.angle_mode == 'degrees':
                return math.radians(angle)
            return angle
        except (ValueError, TypeError):
            raise ValueError("角度必须是数字")
    
    def to_degrees(self, angle):
        """转换为角度"""
        try:
            angle = float(angle)
            if self.angle_mode == 'radians':
                return math.degrees(angle)
            return angle
        except (ValueError, TypeError):
            raise ValueError("角度必须是数字")
    
    # 三角函数
    def sin(self, angle):
        """正弦函数"""
        return math.sin(self.to_radians(angle))
    
    def cos(self, angle):
        """余弦函数"""
        return math.cos(self.to_radians(angle))
    
    def tan(self, angle):
        """正切函数"""
        rad_angle = self.to_radians(angle)
        result = math.tan(rad_angle)
        
        # 检查是否接近无穷大
        if abs(result) > 1e10:
            raise ValueError("正切值无穷大")
        return result
    
    # 科学计算功能
    def power(self, base, exponent):
        """幂运算"""
        try:
            base = float(base)
            exponent = float(exponent)
            return math.pow(base, exponent)
        except (ValueError, TypeError):
            raise ValueError("幂运算的参数必须是数字")
    
    def square_root(self, x):
        """平方根"""
        try:
            x = float(x)
            if x < 0:
                raise ValueError("负数没有实数平方根")
            return math.sqrt(x)
        except (ValueError, TypeError):
            raise ValueError("平方根的参数必须是数字")
    
    def cube_root(self, x):
        """立方根"""
        try:
            x = float(x)
            return math.pow(x, 1/3)
        except (ValueError, TypeError):
            raise ValueError("立方根的参数必须是数字")
    
    def logarithm(self, x, base=10):
        """对数函数"""
        try:
            x = float(x)
            base = float(base)
            if x <= 0:
                raise ValueError("对数的真数必须大于0")
            if base <= 0 or base == 1:
                raise ValueError("对数的底数必须大于0且不等于1")
            return math.log(x, base)
        except (ValueError, TypeError):
            raise ValueError("对数函数的参数必须是数字")
    
    def natural_log(self, x):
        """自然对数"""
        try:
            x = float(x)
            if x <= 0:
                raise ValueError("自然对数的真数必须大于0")
            return math.log(x)
        except (ValueError, TypeError):
            raise ValueError("自然对数的参数必须是数字")
    
    def factorial(self, n):
        """阶乘"""
        try:
            n = float(n)
            if n < 0:
                raise ValueError("阶乘不能计算负数")
            if n != int(n):
                raise ValueError("阶乘只能计算整数")
            if n > 1000:  # 防止计算过大阶乘
                raise ValueError("阶乘数值过大")
            return math.factorial(int(n))
        except (ValueError, TypeError):
            raise ValueError("阶乘的参数必须是数字")
    
    def exp(self, x):
        """指数函数 e^x"""
        try:
            x = float(x)
            result = math.exp(x)
            if math.isinf(result):
                raise ValueError("指数函数结果过大")
            return result
        except (ValueError, TypeError):
            raise ValueError("指数函数的参数必须是数字")
    
    def absolute_value(self, x):
        """绝对值"""
        try:
            x = float(x)
            return abs(x)
        except (ValueError, TypeError):
            raise ValueError("绝对值函数的参数必须是数字")
    
    # 常数
    @property
    def pi(self):
        return math.pi
    
    @property
    def e(self):
        return math.e
    
    def add_to_history(self, expression, result):
        """添加到历史记录"""
        self.history.append(f"{expression} = {result}")
        if len(self.history) > 20:
            self.history.pop(0)
    
    def get_history(self):
        return self.history.copy()