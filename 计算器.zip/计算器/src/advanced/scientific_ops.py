"""
科学计算操作模块
包含幂运算、对数、阶乘等科学计算功能
开发者：李融璿
"""

import math

class ScientificOperations:
    """科学计算操作类"""
    
    @staticmethod
    def power(base, exponent):
        """幂运算"""
        return math.pow(base, exponent)
    
    @staticmethod
    def square_root(x):
        """平方根"""
        if x < 0:
            raise ValueError("负数没有实数平方根")
        return math.sqrt(x)
    
    @staticmethod
    def cube_root(x):
        """立方根"""
        return math.pow(x, 1/3)
    
    @staticmethod
    def nth_root(x, n):
        """n次方根"""
        if n == 0:
            raise ValueError("根指数不能为0")
        if x < 0 and n % 2 == 0:
            raise ValueError("负数的偶数次方根没有实数解")
        return math.pow(x, 1/n)
    
    @staticmethod
    def logarithm(x, base=10):
        """对数函数"""
        if x <= 0:
            raise ValueError("对数的真数必须大于0")
        if base <= 0 or base == 1:
            raise ValueError("对数的底数必须大于0且不等于1")
        
        return math.log(x, base)
    
    @staticmethod
    def natural_log(x):
        """自然对数"""
        if x <= 0:
            raise ValueError("自然对数的真数必须大于0")
        return math.log(x)
    
    @staticmethod
    def common_log(x):
        """常用对数（以10为底）"""
        if x <= 0:
            raise ValueError("常用对数的真数必须大于0")
        return math.log10(x)
    
    @staticmethod
    def factorial(n):
        """阶乘"""
        if n < 0:
            raise ValueError("阶乘只能计算非负整数")
        if n != int(n):
            raise ValueError("阶乘只能计算整数")
        return math.factorial(int(n))
    
    @staticmethod
    def exp(x):
        """指数函数 e^x"""
        return math.exp(x)
    
    @staticmethod
    def absolute_value(x):
        """绝对值"""
        return abs(x)
    
    @staticmethod
    def modulus(x, y):
        """取模运算"""
        if y == 0:
            raise ValueError("除数不能为0")
        return x % y
    
    @staticmethod
    def permutation(n, r):
        """排列数 P(n, r)"""
        if n < 0 or r < 0:
            raise ValueError("排列数的参数必须是非负整数")
        if r > n:
            raise ValueError("r 不能大于 n")
        return math.factorial(n) // math.factorial(n - r)
    
    @staticmethod
    def combination(n, r):
        """组合数 C(n, r)"""
        if n < 0 or r < 0:
            raise ValueError("组合数的参数必须是非负整数")
        if r > n:
            raise ValueError("r 不能大于 n")
        return math.factorial(n) // (math.factorial(r) * math.factorial(n - r))