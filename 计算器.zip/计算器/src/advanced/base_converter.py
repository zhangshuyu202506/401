"""
进制转换模块
支持二进制、八进制、十进制、十六进制之间的转换
开发者：张书宇
"""

class BaseConverter:
    """进制转换器"""
    
    def __init__(self):
        self.bases = {
            'binary': 2,
            'octal': 8, 
            'decimal': 10,
            'hexadecimal': 16
        }
        
        # 定义每个进制的有效字符
        self.valid_chars = {
            'binary': set('01'),
            'octal': set('01234567'),
            'decimal': set('0123456789'),
            'hexadecimal': set('0123456789ABCDEFabcdef')
        }
        
        # 显示名称映射
        self.display_names = {
            'binary': '二进制',
            'octal': '八进制', 
            'decimal': '十进制',
            'hexadecimal': '十六进制'
        }
    
    def convert(self, value, from_base, to_base):
        """
        进制转换
        
        Args:
            value: 要转换的值（字符串）
            from_base: 原进制
            to_base: 目标进制
            
        Returns:
            转换后的字符串
            
        Raises:
            ValueError: 当输入值无效或进制不支持时
        """
        # 验证输入
        if not value:
            raise ValueError("输入值不能为空")
        
        # 转换为大写以处理十六进制
        value_upper = value.upper()
        
        # 验证输入值是否适合原进制
        if not self.validate_input(value_upper, from_base):
            raise ValueError(f"无效的{self.display_names[from_base]}数: {value}")
        
        try:
            # 转换为十进制
            decimal_value = int(value_upper, self.bases[from_base])
        except ValueError as e:
            raise ValueError(f"无效的{self.display_names[from_base]}数: {value}") from e
        
        # 从十进制转换为目标进制
        if to_base == 'binary':
            return bin(decimal_value)[2:]
        elif to_base == 'octal':
            return oct(decimal_value)[2:]
        elif to_base == 'decimal':
            return str(decimal_value)
        elif to_base == 'hexadecimal':
            return hex(decimal_value)[2:].upper()
        else:
            raise ValueError(f"不支持的进制: {to_base}")
    
    def validate_input(self, value, base):
        """验证输入是否有效"""
        if base not in self.valid_chars:
            return False
        
        valid_char_set = self.valid_chars[base]
        return all(char in valid_char_set for char in value)
    
    def get_all_conversions(self, value, from_base):
        """获取所有进制的转换结果"""
        results = {}
        
        for base_name in self.bases:
            if base_name != from_base:
                try:
                    results[base_name] = self.convert(value, from_base, base_name)
                except ValueError:
                    results[base_name] = "无效输入"
        
        return results
    
    def get_base_display_name(self, base_key):
        """获取进制的显示名称"""
        return self.display_names.get(base_key, base_key)
    
    def get_base_key_from_display_name(self, display_name):
        """根据显示名称获取进制键值"""
        reverse_mapping = {v: k for k, v in self.display_names.items()}
        return reverse_mapping.get(display_name, display_name)
    
    def decimal_to_binary(self, decimal_num):
        """十进制转二进制"""
        return self.convert(str(decimal_num), 'decimal', 'binary')
    
    def decimal_to_octal(self, decimal_num):
        """十进制转八进制"""
        return self.convert(str(decimal_num), 'decimal', 'octal')
    
    def decimal_to_hex(self, decimal_num):
        """十进制转十六进制"""
        return self.convert(str(decimal_num), 'decimal', 'hexadecimal')
    
    def binary_to_decimal(self, binary_num):
        """二进制转十进制"""
        return self.convert(binary_num, 'binary', 'decimal')
    
    def binary_to_octal(self, binary_num):
        """二进制转八进制"""
        return self.convert(binary_num, 'binary', 'octal')
    
    def binary_to_hex(self, binary_num):
        """二进制转十六进制"""
        return self.convert(binary_num, 'binary', 'hexadecimal')
    
    def octal_to_decimal(self, octal_num):
        """八进制转十进制"""
        return self.convert(octal_num, 'octal', 'decimal')
    
    def octal_to_binary(self, octal_num):
        """八进制转二进制"""
        return self.convert(octal_num, 'octal', 'binary')
    
    def octal_to_hex(self, octal_num):
        """八进制转十六进制"""
        return self.convert(octal_num, 'octal', 'hexadecimal')
    
    def hex_to_decimal(self, hex_num):
        """十六进制转十进制"""
        return self.convert(hex_num, 'hexadecimal', 'decimal')
    
    def hex_to_binary(self, hex_num):
        """十六进制转二进制"""
        return self.convert(hex_num, 'hexadecimal', 'binary')
    
    def hex_to_octal(self, hex_num):
        """十六进制转八进制"""
        return self.convert(hex_num, 'hexadecimal', 'octal')
    
    def format_binary_with_spaces(self, binary_str, group_size=4):
        """将二进制数字格式化为带空格的格式，便于阅读"""
        # 反转字符串以便从右向左分组
        reversed_str = binary_str[::-1]
        grouped = [reversed_str[i:i+group_size] for i in range(0, len(reversed_str), group_size)]
        # 重新连接并反转回来
        return ' '.join(grouped)[::-1]
    
    def get_conversion_table(self, value, from_base):
        """获取完整的转换表格"""
        table = {}
        for to_base in self.bases:
            if to_base != from_base:
                try:
                    result = self.convert(value, from_base, to_base)
                    table[self.display_names[to_base]] = result
                except ValueError as e:
                    table[self.display_names[to_base]] = f"错误: {str(e)}"
        
        return table