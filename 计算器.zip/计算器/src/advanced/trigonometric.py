"""
三角函数计算模块
支持角度/弧度转换和常用三角函数计算
开发者：李融璿
"""

import math

class TrigonometricCalculator:
    """三角函数计算器"""
    
    def __init__(self):
        self.angle_mode = 'degrees'  # 默认角度模式
    
    def set_angle_mode(self, mode):
        """设置角度模式: 'degrees' 或 'radians'"""
        if mode in ['degrees', 'radians']:
            self.angle_mode = mode
        else:
            raise ValueError("角度模式必须是 'degrees' 或 'radians'")
    
    def get_angle_mode(self):
        """获取当前角度模式"""
        return self.angle_mode
    
    def to_radians(self, angle):
        """转换为弧度"""
        if self.angle_mode == 'degrees':
            return math.radians(angle)
        return angle
    
    def to_degrees(self, angle):
        """转换为角度"""
        if self.angle_mode == 'radians':
            return math.degrees(angle)
        return angle
    
    def sin(self, angle):
        """正弦函数"""
        rad_angle = self.to_radians(angle)
        return math.sin(rad_angle)
    
    def cos(self, angle):
        """余弦函数"""
        rad_angle = self.to_radians(angle)
        return math.cos(rad_angle)
    
    def tan(self, angle):
        """正切函数"""
        rad_angle = self.to_radians(angle)
        result = math.tan(rad_angle)
        
        # 检查是否接近无穷大（90度或π/2弧度）
        if abs(result) > 1e10:
            raise ValueError("正切值无穷大（角度接近90度或π/2弧度）")
        return result
    
    def asin(self, value):
        """反正弦函数"""
        if abs(value) > 1:
            raise ValueError("反正弦函数的输入必须在 -1 到 1 之间")
        result = math.asin(value)
        return self.to_degrees(result) if self.angle_mode == 'degrees' else result
    
    def acos(self, value):
        """反余弦函数"""
        if abs(value) > 1:
            raise ValueError("反余弦函数的输入必须在 -1 到 1 之间")
        result = math.acos(value)
        return self.to_degrees(result) if self.angle_mode == 'degrees' else result
    
    def atan(self, value):
        """反正切函数"""
        result = math.atan(value)
        return self.to_degrees(result) if self.angle_mode == 'degrees' else result
    
    def atan2(self, y, x):
        """两个参数的反正切函数"""
        result = math.atan2(y, x)
        return self.to_degrees(result) if self.angle_mode == 'degrees' else result
    
    def sinh(self, angle):
        """双曲正弦"""
        rad_angle = self.to_radians(angle)
        return math.sinh(rad_angle)
    
    def cosh(self, angle):
        """双曲余弦"""
        rad_angle = self.to_radians(angle)
        return math.cosh(rad_angle)
    
    def tanh(self, angle):
        """双曲正切"""
        rad_angle = self.to_radians(angle)
        return math.tanh(rad_angle)
    
    def sec(self, angle):
        """正割函数"""
        cos_val = self.cos(angle)
        if abs(cos_val) < 1e-10:
            raise ValueError("正割函数在角度为90度或π/2弧度时未定义")
        return 1 / cos_val
    
    def csc(self, angle):
        """余割函数"""
        sin_val = self.sin(angle)
        if abs(sin_val) < 1e-10:
            raise ValueError("余割函数在角度为0度或0弧度时未定义")
        return 1 / sin_val
    
    def cot(self, angle):
        """余切函数"""
        tan_val = self.tan(angle)
        if abs(tan_val) < 1e-10:
            raise ValueError("余切函数在角度为0度或0弧度时未定义")
        return 1 / tan_val
    
    def degrees_to_dms(self, degrees):
        """将十进制度转换为度分秒格式"""
        if degrees < 0:
            sign = -1
            degrees = abs(degrees)
        else:
            sign = 1
        
        d = int(degrees)
        minutes = (degrees - d) * 60
        m = int(minutes)
        s = (minutes - m) * 60
        
        return sign * d, m, s
    
    def dms_to_degrees(self, degrees, minutes, seconds):
        """将度分秒转换为十进制度"""
        sign = 1 if degrees >= 0 else -1
        degrees = abs(degrees)
        return sign * (degrees + minutes/60 + seconds/3600)