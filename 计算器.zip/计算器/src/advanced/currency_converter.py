"""
汇率转换器模块
支持实时汇率更新和手动设置汇率
"""

import json
import os
import requests
from datetime import datetime, timedelta

class CurrencyConverter:
    """汇率转换器类"""
    
    def __init__(self):
        self.rates = {}
        self.last_update = None
        self.data_file = 'currency_rates.json'
        self.load_rates()
        
        # 主要货币列表
        self.currencies = {
            'USD': '美元',
            'EUR': '欧元',
            'GBP': '英镑',
            'JPY': '日元',
            'CNY': '人民币',
            'CAD': '加元',
            'AUD': '澳元',
            'CHF': '瑞士法郎',
            'HKD': '港币',
            'KRW': '韩元',
            'SGD': '新加坡元',
            'INR': '印度卢比',
            'RUB': '俄罗斯卢布',
            'BRL': '巴西雷亚尔',
            'MXN': '墨西哥比索'
        }
    
    def load_rates(self):
        """从文件加载汇率数据"""
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.rates = data.get('rates', {})
                    self.last_update = data.get('last_update')
                    
                    # 检查数据是否过期（超过1天）
                    if self.last_update:
                        last_update_date = datetime.fromisoformat(self.last_update)
                        if datetime.now() - last_update_date > timedelta(days=1):
                            self.update_rates_from_api()
        except Exception as e:
            print(f"加载汇率数据失败: {e}")
            self.rates = self.get_default_rates()
    
    def save_rates(self):
        """保存汇率数据到文件"""
        try:
            data = {
                'rates': self.rates,
                'last_update': datetime.now().isoformat()
            }
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存汇率数据失败: {e}")
    
    def get_default_rates(self):
        """获取默认汇率（当API不可用时使用）"""
        return {
            'USD': 1.0,
            'EUR': 0.85,
            'GBP': 0.73,
            'JPY': 110.0,
            'CNY': 6.5,
            'CAD': 1.25,
            'AUD': 1.35,
            'CHF': 0.92,
            'HKD': 7.78,
            'KRW': 1180.0,
            'SGD': 1.35,
            'INR': 74.0,
            'RUB': 73.0,
            'BRL': 5.3,
            'MXN': 20.0
        }
    
    def update_rates_from_api(self):
        """从API获取最新汇率"""
        try:
            # 使用免费的汇率API（示例API，实际使用时可能需要注册获取API key）
            api_url = "https://api.exchangerate-api.com/v4/latest/USD"
            response = requests.get(api_url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                self.rates = data.get('rates', {})
                self.last_update = datetime.now().isoformat()
                self.save_rates()
                return True
            else:
                # 如果API失败，使用默认汇率
                self.rates = self.get_default_rates()
                return False
                
        except Exception as e:
            print(f"从API获取汇率失败: {e}")
            self.rates = self.get_default_rates()
            return False
    
    def update_rates_manually(self, base_currency, rates_dict):
        """手动更新汇率"""
        try:
            if base_currency in self.currencies:
                # 确保基础货币的汇率为1
                rates_dict[base_currency] = 1.0
                self.rates.update(rates_dict)
                self.last_update = datetime.now().isoformat()
                self.save_rates()
                return True
            return False
        except Exception as e:
            print(f"手动更新汇率失败: {e}")
            return False
    
    def get_available_currencies(self):
        """获取可用的货币列表"""
        return [(code, name) for code, name in self.currencies.items()]
    
    def get_currency_display_name(self, currency_code):
        """获取货币的显示名称"""
        return f"{self.currencies.get(currency_code, currency_code)} ({currency_code})"
    
    def convert(self, amount, from_currency, to_currency):
        """执行货币转换"""
        try:
            if from_currency not in self.rates or to_currency not in self.rates:
                raise ValueError(f"不支持的货币代码: {from_currency} 或 {to_currency}")
            
            # 转换为美元，然后再转换为目标货币
            amount_in_usd = amount / self.rates[from_currency]
            result = amount_in_usd * self.rates[to_currency]
            
            return round(result, 4)
        except ZeroDivisionError:
            raise ValueError("汇率数据错误：除零错误")
        except Exception as e:
            raise ValueError(f"转换失败: {str(e)}")
    
    def get_all_rates(self, base_currency='USD'):
        """获取所有货币相对于基础货币的汇率"""
        try:
            if base_currency not in self.rates:
                return {}
            
            base_rate = self.rates[base_currency]
            all_rates = {}
            
            for currency, rate in self.rates.items():
                if currency in self.currencies:
                    converted_rate = rate / base_rate
                    all_rates[currency] = round(converted_rate, 6)
            
            return all_rates
        except Exception as e:
            print(f"获取所有汇率失败: {e}")
            return {}
    
    def get_last_update_time(self):
        """获取最后更新时间"""
        if self.last_update:
            return datetime.fromisoformat(self.last_update).strftime("%Y-%m-%d %H:%M:%S")
        return "未知"