"""
单位转换模块
支持长度、重量、温度、面积、体积、速度等常见单位转换
开发者：张书宇
"""

class UnitConverter:
    """单位转换器"""
    
    def __init__(self):
        # 定义转换因子（相对于基准单位）
        self.conversion_factors = {
            '长度': {
                'meter': 1.0,
                'kilometer': 1000.0,
                'centimeter': 0.01,
                'millimeter': 0.001,
                'mile': 1609.344,
                'yard': 0.9144,
                'foot': 0.3048,
                'inch': 0.0254,
                'nautical_mile': 1852.0,
                'light_year': 9.46073e15
            },
            '重量': {
                'kilogram': 1.0,
                'gram': 0.001,
                'milligram': 0.000001,
                'pound': 0.45359237,
                'ounce': 0.028349523125,
                'ton': 1000.0,
                'metric_ton': 1000.0,
                'carat': 0.0002
            },
            '温度': {
                # 温度转换需要特殊处理
            },
            '面积': {
                'square_meter': 1.0,
                'square_kilometer': 1000000.0,
                'square_centimeter': 0.0001,
                'square_millimeter': 0.000001,
                'hectare': 10000.0,
                'acre': 4046.8564224,
                'square_mile': 2589988.110336,
                'square_foot': 0.09290304,
                'square_inch': 0.00064516,
                'square_yard': 0.83612736
            },
            '体积': {
                'cubic_meter': 1.0,
                'liter': 0.001,
                'milliliter': 0.000001,
                'gallon': 0.00378541,
                'quart': 0.000946353,
                'pint': 0.000473176,
                'cup': 0.000236588,
                'fluid_ounce': 0.0000295735,
                'cubic_centimeter': 0.000001,
                'cubic_foot': 0.0283168,
                'cubic_inch': 0.0000163871
            },
            '速度': {
                'meter_per_second': 1.0,
                'kilometer_per_hour': 0.277778,
                'mile_per_hour': 0.44704,
                'knot': 0.514444,
                'foot_per_second': 0.3048,
                'mach': 340.3,  # 音速，近似值
                'light_speed': 299792458.0
            }
        }
        
        # 温度转换公式
        self.temperature_formulas = {
            'celsius': {
                'fahrenheit': lambda c: (c * 9/5) + 32,
                'kelvin': lambda c: c + 273.15
            },
            'fahrenheit': {
                'celsius': lambda f: (f - 32) * 5/9,
                'kelvin': lambda f: (f - 32) * 5/9 + 273.15
            },
            'kelvin': {
                'celsius': lambda k: k - 273.15,
                'fahrenheit': lambda k: (k - 273.15) * 9/5 + 32
            }
        }
        
        # 单位显示名称映射
        self.display_names = {
            # 长度
            'meter': '米',
            'kilometer': '千米',
            'centimeter': '厘米',
            'millimeter': '毫米',
            'mile': '英里',
            'yard': '码',
            'foot': '英尺',
            'inch': '英寸',
            'nautical_mile': '海里',
            'light_year': '光年',
            
            # 重量
            'kilogram': '千克',
            'gram': '克',
            'milligram': '毫克',
            'pound': '磅',
            'ounce': '盎司',
            'ton': '吨',
            'metric_ton': '公吨',
            'carat': '克拉',
            
            # 温度
            'celsius': '摄氏度',
            'fahrenheit': '华氏度',
            'kelvin': '开尔文',
            
            # 面积
            'square_meter': '平方米',
            'square_kilometer': '平方千米',
            'square_centimeter': '平方厘米',
            'square_millimeter': '平方毫米',
            'hectare': '公顷',
            'acre': '英亩',
            'square_mile': '平方英里',
            'square_foot': '平方英尺',
            'square_inch': '平方英寸',
            'square_yard': '平方码',
            
            # 体积
            'cubic_meter': '立方米',
            'liter': '升',
            'milliliter': '毫升',
            'gallon': '加仑',
            'quart': '夸脱',
            'pint': '品脱',
            'cup': '杯',
            'fluid_ounce': '液量盎司',
            'cubic_centimeter': '立方厘米',
            'cubic_foot': '立方英尺',
            'cubic_inch': '立方英寸',
            
            # 速度
            'meter_per_second': '米/秒',
            'kilometer_per_hour': '千米/时',
            'mile_per_hour': '英里/时',
            'knot': '节',
            'foot_per_second': '英尺/秒',
            'mach': '马赫',
            'light_speed': '光速'
        }
    
    def convert(self, value, category, from_unit_display, to_unit_display):
        """
        通用单位转换方法
        
        Args:
            value: 要转换的数值
            category: 单位类别
            from_unit_display: 源单位显示名称
            to_unit_display: 目标单位显示名称
            
        Returns:
            转换后的数值
        """
        # 将显示名称转换为内部键值
        from_unit = self.get_internal_name(from_unit_display)
        to_unit = self.get_internal_name(to_unit_display)
        
        if category == '温度':
            return self.convert_temperature(value, from_unit, to_unit)
        else:
            return self._convert_standard(value, from_unit, to_unit, category)
    
    def _convert_standard(self, value, from_unit, to_unit, category):
        """标准单位转换（非温度）"""
        value = float(value)
        
        if from_unit == to_unit:
            return value
        
        if category not in self.conversion_factors:
            raise ValueError(f"不支持的转换类别: {category}")
        
        factors = self.conversion_factors[category]
        
        if from_unit not in factors:
            raise ValueError(f"不支持的{category}单位: {self.get_display_name(from_unit)}")
        
        if to_unit not in factors:
            raise ValueError(f"不支持的{category}单位: {self.get_display_name(to_unit)}")
        
        # 转换为基准单位，然后转换为目标单位
        base_value = value * factors[from_unit]
        result = base_value / factors[to_unit]
        
        return result
    
    def convert_temperature(self, value, from_unit, to_unit):
        """温度单位转换"""
        value = float(value)
        
        if from_unit == to_unit:
            return value
        
        if from_unit in self.temperature_formulas and to_unit in self.temperature_formulas[from_unit]:
            return self.temperature_formulas[from_unit][to_unit](value)
        else:
            raise ValueError(f"不支持的温度单位转换: {self.get_display_name(from_unit)} 到 {self.get_display_name(to_unit)}")
    
    def get_available_units(self, category):
        """获取指定类别下可用的单位列表"""
        if category == '温度':
            return list(self.temperature_formulas.keys())
        elif category in self.conversion_factors:
            return list(self.conversion_factors[category].keys())
        else:
            return []
    
    def get_display_name(self, internal_name):
        """获取单位的显示名称"""
        return self.display_names.get(internal_name, internal_name)
    
    def get_internal_name(self, display_name):
        """根据显示名称获取内部名称"""
        reverse_mapping = {v: k for k, v in self.display_names.items()}
        return reverse_mapping.get(display_name, display_name)
    
    def get_available_categories(self):
        """获取可用的转换类别"""
        return list(self.conversion_factors.keys()) + ['温度']
    
    def get_conversion_info(self, category, unit):
        """获取单位的转换信息"""
        if category == '温度':
            return f"温度单位: {self.get_display_name(unit)}"
        elif category in self.conversion_factors and unit in self.conversion_factors[category]:
            factor = self.conversion_factors[category][unit]
            base_unit = self.get_base_unit(category)
            return f"1 {self.get_display_name(unit)} = {factor} {self.get_display_name(base_unit)}"
        else:
            return "未知单位"
    
    def get_base_unit(self, category):
        """获取基准单位"""
        base_units = {
            '长度': 'meter',
            '重量': 'kilogram',
            '面积': 'square_meter',
            '体积': 'cubic_meter',
            '速度': 'meter_per_second'
        }
        return base_units.get(category, '')