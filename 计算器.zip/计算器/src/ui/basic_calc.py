"""
基础计算器界面模块
两人合作开发部分
"""

import tkinter as tk
from tkinter import ttk, messagebox
from src.core.calculator import CalculatorEngine

class BasicCalculatorUI:
    """基础计算器界面类"""
    
    def __init__(self, parent, main_app):
        self.parent = parent
        self.main_app = main_app
        self.calculator = CalculatorEngine()
        
        self.setup_ui()
    
    def setup_ui(self):
        """设置用户界面"""
        # 主框架
        main_frame = ttk.Frame(self.parent)
        main_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # 显示区域
        self.setup_display(main_frame)
        
        # 按钮区域
        self.setup_buttons(main_frame)
        
    def setup_display(self, parent):
        """设置显示区域"""
        display_frame = ttk.Frame(parent)
        display_frame.pack(fill='x', pady=10)
        
        # 显示文本框
        self.display_var = tk.StringVar(value="0")
        self.display = ttk.Entry(
            display_frame,
            textvariable=self.display_var,
            font=('Arial', 18),
            justify='right',
            state='readonly'
        )
        self.display.pack(fill='x', ipady=10)
        
    def setup_buttons(self, parent):
        """设置按钮区域"""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill='both', expand=True)
        
        # 按钮布局
        buttons = [
            ['C', '⌫', '(', ')'],
            ['7', '8', '9', '/'],
            ['4', '5', '6', '*'],
            ['1', '2', '3', '-'],
            ['0', '.', '=', '+']
        ]
        
        # 创建按钮网格
        for i, row in enumerate(buttons):
            button_frame.grid_rowconfigure(i, weight=1)
            for j, text in enumerate(row):
                button_frame.grid_columnconfigure(j, weight=1)
                
                if text == '=':
                    btn = ttk.Button(
                        button_frame, 
                        text=text,
                        command=self.calculate_result,
                        style='Accent.TButton'
                    )
                else:
                    btn = ttk.Button(
                        button_frame, 
                        text=text,
                        command=lambda t=text: self.on_button_click(t)
                    )
                
                btn.grid(row=i, column=j, sticky='nsew', padx=2, pady=2)
                
    def on_button_click(self, button_text):
        """处理按钮点击"""
        current_text = self.display_var.get()
        
        if button_text == 'C':
            # 清除
            self.display_var.set("0")
        elif button_text == '⌫':
            # 退格
            if current_text == "0" or len(current_text) == 1:
                self.display_var.set("0")
            else:
                self.display_var.set(current_text[:-1])
        else:
            # 数字或运算符
            if current_text == "0":
                self.display_var.set(button_text)
            else:
                self.display_var.set(current_text + button_text)
    
    def calculate_result(self):
        """计算结果"""
        try:
            expression = self.display_var.get()
            result = self.calculator.evaluate(expression)
            self.display_var.set(str(result))
            
            # 添加到历史记录
            self.main_app.history_manager.add_entry(expression, str(result))
            
        except ZeroDivisionError:
            messagebox.showerror("计算错误", "不能除以零！")
        except ValueError as e:
            messagebox.showerror("计算错误", str(e))
        except Exception as e:
            messagebox.showerror("错误", f"发生未知错误: {str(e)}")