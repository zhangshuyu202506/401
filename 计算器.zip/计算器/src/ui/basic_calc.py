"""
基础计算器界面模块
"""

import tkinter as tk
from tkinter import ttk, messagebox
from src.core.calculator import CalculatorEngine

class BasicCalculatorUI:
    """基础计算器界面类"""
    
    def __init__(self, parent, main_app):
        self.parent = parent
        self.main_app = main_app
        self.calculator = CalculatorEngine()
        
        self.setup_ui()
    
    def setup_ui(self):
        """设置用户界面"""
        # 主框架
        main_frame = ttk.Frame(self.parent)
        main_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # 显示区域
        self.setup_display(main_frame)
        
        # 按钮区域
        self.setup_buttons(main_frame)
        
    def setup_display(self, parent):
        """设置显示区域"""
        display_frame = ttk.Frame(parent)
        display_frame.pack(fill='x', pady=10)
        
        # 显示文本框
        self.display_var = tk.StringVar(value="0")
        self.display = ttk.Entry(
            display_frame,
            textvariable=self.display_var,
            font=('Arial', 18),
            justify='right',
            state='readonly'
        )
        self.display.pack(fill='x', ipady=10)
        
        # 绑定键盘事件
        self.display.bind('<Key>', self.on_key_press)
        # 让display可以获得焦点
        self.display.bind('<Button-1>', lambda e: self.display.focus_set())
        
    def setup_buttons(self, parent):
        """设置按钮区域"""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill='both', expand=True)
        
        # 按钮布局
        buttons = [
            ['C', '⌫', '(', ')'],
            ['7', '8', '9', '/'],
            ['4', '5', '6', '*'],
            ['1', '2', '3', '-'],
            ['0', '.', '=', '+']
        ]
        
        # 创建按钮网格
        for i, row in enumerate(buttons):
            button_frame.grid_rowconfigure(i, weight=1)
            for j, text in enumerate(row):
                button_frame.grid_columnconfigure(j, weight=1)
                
                if text == '=':
                    btn = ttk.Button(
                        button_frame, 
                        text=text,
                        command=self.calculate_result,
                        style='Accent.TButton'
                    )
                else:
                    btn = ttk.Button(
                        button_frame, 
                        text=text,
                        command=lambda t=text: self.on_button_click(t)
                    )
                
                btn.grid(row=i, column=j, sticky='nsew', padx=2, pady=2)
    
    def on_key_press(self, event):
        """处理键盘输入"""
        # 允许的数字和运算符
        allowed_chars = '0123456789+-*/.()'
        
        if event.char in allowed_chars:
            self.on_button_click(event.char)
            return "break"  # 阻止默认输入
        elif event.keysym == 'Return' or event.keysym == 'equal':
            self.calculate_result()
            return "break"
        elif event.keysym == 'BackSpace':
            self.on_button_click('⌫')
            return "break"
        elif event.keysym == 'Escape':
            self.on_button_click('C')
            return "break"
        else:
            # 阻止其他所有键盘输入
            return "break"
                
    def on_button_click(self, button_text):
        """处理按钮点击"""
        current_text = self.display_var.get()
        
        if button_text == 'C':
            # 清除
            self.display_var.set("0")
        elif button_text == '⌫':
            # 退格
            if current_text == "0" or len(current_text) == 1:
                self.display_var.set("0")
            else:
                self.display_var.set(current_text[:-1])
        else:
            # 数字或运算符
            if current_text == "0":
                self.display_var.set(button_text)
            else:
                self.display_var.set(current_text + button_text)
    
    def calculate_result(self):
        """计算结果"""
        try:
            expression = self.display_var.get()
            result = self.calculator.evaluate(expression)
            
            # 处理浮点数精度问题
            if isinstance(result, float):
                # 检查是否为整数浮点数
                if result.is_integer():
                    result = int(result)
                else:
                    # 四舍五入到合理的小数位数，避免浮点数误差
                    result = round(result, 10)
                    # 移除末尾的0
                    result_str = format(result, '.10f').rstrip('0').rstrip('.')
                    if result_str == '':
                        result_str = '0'
                    result = float(result_str)  # 保持为数字类型
            
            self.display_var.set(str(result))
            
            # 添加到历史记录
            self.main_app.history_manager.add_entry(expression, str(result))
            
        except ZeroDivisionError:
            messagebox.showerror("计算错误", "不能除以零！")
        except ValueError as e:
            messagebox.showerror("计算错误", str(e))
        except Exception as e:
            messagebox.showerror("错误", f"发生未知错误: {str(e)}")