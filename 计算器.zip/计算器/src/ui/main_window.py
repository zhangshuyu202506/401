"""
计算器主窗口模块
集成基础计算、科学计算和转换器功能
"""

import tkinter as tk
from tkinter import ttk, messagebox, Menu, filedialog
import json
import os
from src.core.config import AppConfig
from src.core.history_manager import HistoryManager

class CalculatorMainWindow:
    """计算器主窗口类"""
    
    def __init__(self, root):
        self.root = root
        self.config = AppConfig()
        self.history_manager = HistoryManager()
        
        # 初始化界面组件
        self.setup_main_window()
        self.create_menu_bar()
        self.create_main_interface()
        self.create_status_bar()
        
        # 应用配置
        self.apply_config()
        
        # 绑定事件
        self.bind_events()
    
    def setup_main_window(self):
        """设置主窗口属性"""
        self.root.title("401一组多功能计算器 v2.0")
        
        # 设置窗口大小和位置
        width = self.config.get('window.width', 800)
        height = self.config.get('window.height', 650)
        self.root.geometry(f"{width}x{height}")
        
        # 设置最小尺寸
        self.root.minsize(700, 550)
        
        # 设置窗口图标
        try:
            self.root.iconbitmap('resources/icons/calculator.ico')
        except:
            pass  # 图标文件不存在时忽略
        
        # 窗口关闭事件处理
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # 设置样式
        self.setup_styles()
    
    def setup_styles(self):
        """设置界面样式"""
        style = ttk.Style()
        
        # 配置不同主题的样式
        if self.config.get('window.theme', 'light') == 'dark':
            self.setup_dark_theme(style)
        else:
            self.setup_light_theme(style)
    
    def setup_light_theme(self, style):
        """设置浅色主题"""
        style.theme_use('clam')
        style.configure('Accent.TButton', background='#0078d4', foreground='white')
        style.configure('Header.TLabel', font=('Arial', 12, 'bold'))
        style.configure('Status.TLabel', background='#f0f0f0', relief='sunken')
    
    def setup_dark_theme(self, style):
        """设置深色主题"""
        style.theme_use('clam')
        style.configure('.', background='#2b2b2b', foreground='white')
        style.configure('Accent.TButton', background='#0078d4', foreground='white')
        style.configure('Header.TLabel', font=('Arial', 12, 'bold'), background='#2b2b2b', foreground='white')
        style.configure('Status.TLabel', background='#3c3c3c', foreground='white', relief='sunken')
        self.root.configure(bg='#2b2b2b')
    
    def create_menu_bar(self):
        """创建菜单栏:cite[7]"""
        menubar = Menu(self.root)
        self.root.config(menu=menubar)
        
        # 文件菜单
        file_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="文件", menu=file_menu)
        file_menu.add_command(label="新建", command=self.new_file, accelerator="Ctrl+N")
        file_menu.add_command(label="打开...", command=self.open_file, accelerator="Ctrl+O")
        file_menu.add_command(label="保存历史...", command=self.save_history, accelerator="Ctrl+S")
        file_menu.add_separator()
        file_menu.add_command(label="导出结果...", command=self.export_results)
        file_menu.add_separator()
        file_menu.add_command(label="退出", command=self.on_closing, accelerator="Ctrl+Q")
        
        # 编辑菜单
        edit_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="编辑", menu=edit_menu)
        edit_menu.add_command(label="清空历史", command=self.clear_history)
        edit_menu.add_command(label="复制结果", command=self.copy_result, accelerator="Ctrl+C")
        edit_menu.add_separator()
        edit_menu.add_command(label="偏好设置", command=self.show_settings)
        
        # 视图菜单
        view_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="视图", menu=view_menu)
        
        # 主题子菜单
        theme_menu = Menu(view_menu, tearoff=0)
        view_menu.add_cascade(label="主题", menu=theme_menu)
        theme_menu.add_command(label="浅色主题", command=lambda: self.change_theme("light"))
        theme_menu.add_command(label="深色主题", command=lambda: self.change_theme("dark"))
        
        view_menu.add_separator()
        view_menu.add_command(label="基础计算器", command=lambda: self.show_tab(0))
        view_menu.add_command(label="科学计算器", command=lambda: self.show_tab(1))
        view_menu.add_command(label="转换器", command=lambda: self.show_tab(2))
        
        # 工具菜单
        tools_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="工具", menu=tools_menu)
        tools_menu.add_command(label="计算历史", command=self.show_history)
        tools_menu.add_command(label="函数帮助", command=self.show_help)
        
        # 帮助菜单
        help_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="帮助", menu=help_menu)
        help_menu.add_command(label="使用说明", command=self.show_instructions)
        help_menu.add_command(label="关于", command=self.show_about)
        
        # 绑定快捷键
        self.root.bind('<Control-n>', lambda e: self.new_file())
        self.root.bind('<Control-o>', lambda e: self.open_file())
        self.root.bind('<Control-s>', lambda e: self.save_history())
        self.root.bind('<Control-q>', lambda e: self.on_closing())
        self.root.bind('<Control-c>', lambda e: self.copy_result())
    
    def create_main_interface(self):
        """创建主界面:cite[6]"""
        # 创建主框架
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # 创建标签页控件:cite[6]
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill='both', expand=True)
        
        # 基础计算器标签页
        self.basic_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.basic_frame, text="基础计算")
        self.setup_basic_calculator()
        
        # 科学计算器标签页（李融璿负责）
        self.scientific_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.scientific_frame, text="科学计算")
        self.setup_scientific_calculator()
        
        # 转换器标签页（张书宇负责）
        self.converter_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.converter_frame, text="转换器")
        self.setup_converter_calculator()
        
        # 绑定标签页切换事件
        self.notebook.bind('<<NotebookTabChanged>>', self.on_tab_changed)
    
    def setup_basic_calculator(self):
        """设置基础计算器界面"""
        try:
            from src.ui.basic_calc import BasicCalculatorUI
            self.basic_calc_ui = BasicCalculatorUI(self.basic_frame, self)
            print("✅ 基础计算器界面加载成功")
        except Exception as e:
            print(f"❌ 基础计算器界面加载失败: {e}")
            self.create_fallback_interface(self.basic_frame, "基础计算器")
    
    def setup_scientific_calculator(self):
        """设置科学计算器界面"""
        try:
            from src.ui.scientific_calc import ScientificCalculatorUI
            self.scientific_calc_ui = ScientificCalculatorUI(self.scientific_frame, self)
            print("✅ 科学计算器界面加载成功")
        except Exception as e:
            print(f"❌ 科学计算器界面加载失败: {e}")
            self.create_fallback_interface(self.scientific_frame, "科学计算器")
    
    def setup_converter_calculator(self):
        """设置转换器界面"""
        try:
            from src.ui.converter_calc import ConverterCalculatorUI
            self.converter_calc_ui = ConverterCalculatorUI(self.converter_frame, self)
            print("✅ 转换器界面加载成功")
        except Exception as e:
            print(f"❌ 转换器界面加载失败: {e}")
            self.create_fallback_interface(self.converter_frame, "转换器")
    
    def create_fallback_interface(self, parent, name):
        """创建备用界面（当主要界面加载失败时）"""
        label = ttk.Label(parent, text=f"{name} - 功能开发中", 
                         font=('Arial', 16), foreground='gray')
        label.pack(expand=True)
        
        info_label = ttk.Label(parent, 
                              text="该功能模块正在开发中，敬请期待...",
                              font=('Arial', 12))
        info_label.pack(pady=10)
    
    def create_status_bar(self):
        """创建状态栏:cite[7]"""
        status_frame = ttk.Frame(self.root, relief='sunken', style='Status.TLabel')
        status_frame.pack(fill='x', side='bottom')
        
        # 状态信息
        self.status_var = tk.StringVar(value="就绪")
        status_label = ttk.Label(status_frame, textvariable=self.status_var, 
                               anchor='w', style='Status.TLabel')
        status_label.pack(side='left', padx=5)
        
        # 当前模式显示
        self.mode_var = tk.StringVar(value="基础模式")
        mode_label = ttk.Label(status_frame, textvariable=self.mode_var, 
                             anchor='e', style='Status.TLabel')
        mode_label.pack(side='right', padx=5)
        
        # 内存状态
        self.memory_var = tk.StringVar(value="")
        memory_label = ttk.Label(status_frame, textvariable=self.memory_var,
                               anchor='center', style='Status.TLabel')
        memory_label.pack(side='right', padx=20)
    
    def bind_events(self):
        """绑定事件处理"""
        # 窗口大小变化事件
        self.root.bind('<Configure>', self.on_window_resize)
        
        # 键盘事件
        self.root.bind('<F1>', lambda e: self.show_help())
        self.root.bind('<F11>', lambda e: self.toggle_fullscreen())
    
    def apply_config(self):
        """应用配置设置"""
        # 应用主题
        self.change_theme(self.config.get('window.theme', 'light'), initial=True)
        
        # 应用窗口状态
        if self.config.get('window.maximized', False):
            self.root.state('zoomed')
    
    def change_theme(self, theme_name, initial=False):
        """切换主题"""
        self.config.set('window.theme', theme_name)
        
        # 重新设置样式
        self.setup_styles()
        
        if not initial:
            messagebox.showinfo("主题切换", f"已切换到{theme_name}主题")
    
    def show_tab(self, tab_index):
        """显示指定标签页"""
        self.notebook.select(tab_index)
    
    def on_tab_changed(self, event):
        """标签页切换事件处理"""
        current_tab = self.notebook.index(self.notebook.select())
        tab_names = ["基础模式", "科学计算模式", "转换器模式"]
        self.mode_var.set(tab_names[current_tab])
        
        # 更新状态栏
        self.status_var.set(f"已切换到 {tab_names[current_tab]}")
    
    def on_window_resize(self, event):
        """窗口大小变化事件处理"""
        # 只有在事件来自根窗口时才处理
        if event.widget == self.root:
            self.config.set('window.width', self.root.winfo_width())
            self.config.set('window.height', self.root.winfo_height())
    
    def toggle_fullscreen(self):
        """切换全屏模式"""
        current_state = self.root.attributes('-fullscreen')
        self.root.attributes('-fullscreen', not current_state)
    
    # 菜单功能实现
    def new_file(self):
        """新建文件"""
        self.clear_history()
        self.status_var.set("已清空历史记录")
    
    def open_file(self):
        """打开文件"""
        filename = filedialog.askopenfilename(
            title="打开计算历史",
            filetypes=[("JSON文件", "*.json"), ("文本文件", "*.txt"), ("所有文件", "*.*")]
        )
        if filename:
            try:
                self.history_manager.load_from_file(filename)
                self.status_var.set(f"已加载历史记录: {len(self.history_manager.get_history())} 条")
                messagebox.showinfo("成功", "历史记录加载完成")
            except Exception as e:
                messagebox.showerror("错误", f"打开文件失败: {e}")
    
    def save_history(self):
        """保存历史记录"""
        if not self.history_manager.get_history():
            messagebox.showwarning("警告", "没有历史记录可保存")
            return
        
        filename = filedialog.asksaveasfilename(
            title="保存计算历史",
            defaultextension=".json",
            filetypes=[("JSON文件", "*.json"), ("文本文件", "*.txt"), ("所有文件", "*.*")]
        )
        if filename:
            try:
                self.history_manager.save_to_file(filename)
                self.status_var.set(f"历史记录已保存到: {filename}")
                messagebox.showinfo("成功", "历史记录保存成功")
            except Exception as e:
                messagebox.showerror("错误", f"保存文件失败: {e}")
    
    def export_results(self):
        """导出计算结果"""
        # 实现导出功能
        messagebox.showinfo("导出", "导出功能开发中")
    
    def clear_history(self):
        """清空历史记录"""
        if self.history_manager.get_history():
            if messagebox.askyesno("确认", "确定要清空所有历史记录吗？"):
                self.history_manager.clear_history()
                self.status_var.set("历史记录已清空")
    
    def copy_result(self):
        """复制结果"""
        # 获取当前活动标签页的显示内容
        current_tab = self.notebook.index(self.notebook.select())
        try:
            if current_tab == 0:  # 基础计算器
                result = self.basic_calc_ui.display_var.get()
            elif current_tab == 1:  # 科学计算器
                result = self.scientific_calc_ui.display_var.get()
            else:  # 转换器
                result = "转换器内容"
            
            self.root.clipboard_clear()
            self.root.clipboard_append(result)
            self.status_var.set("结果已复制到剪贴板")
        except Exception as e:
            messagebox.showerror("错误", f"复制失败: {e}")
    
    def show_settings(self):
        """显示设置对话框"""
        self.open_settings_dialog()
    
    def show_history(self):
        """显示历史记录窗口"""
        self.open_history_dialog()
    
    def show_help(self):
        """显示函数帮助"""
        help_text = """
函数使用帮助：

三角函数：
sin(x), cos(x), tan(x) - 正弦、余弦、正切
asin(x), acos(x), atan(x) - 反正弦、反余弦、反正切

对数函数：
log(x) - 常用对数（以10为底）
ln(x) - 自然对数（以e为底）

其他函数：
sqrt(x) - 平方根
exp(x) - 指数函数
abs(x) - 绝对值

进制转换：
支持二进制、八进制、十进制、十六进制相互转换

单位转换：
支持长度、重量、温度、面积等单位转换
        """
        messagebox.showinfo("函数帮助", help_text)
    
    def show_instructions(self):
        """显示使用说明"""
        instructions = """
401一组多功能计算器使用说明

1. 基础计算
   - 支持四则运算和复杂表达式
   - 使用括号控制运算优先级
   - 实时显示计算结果

2. 科学计算
   - 三角函数计算（支持角度/弧度切换）
   - 对数函数和指数函数
   - 幂运算和根号运算
   - 排列组合计算

3. 转换器
   - 进制转换：二进制、八进制、十进制、十六进制
   - 单位转换：长度、重量、温度、面积等

快捷键：
Ctrl+N - 新建    Ctrl+O - 打开
Ctrl+S - 保存    Ctrl+Q - 退出
Ctrl+C - 复制结果
        """
        messagebox.showinfo("使用说明", instructions)
    
    def show_about(self):
        """显示关于信息"""
        about_info = """
401一组多功能计算器

版本: 2.0
开发团队: 张书宇 & 李融璿
课程: 软件工程

功能特性:
- 基础数学运算
- 科学计算功能
- 单位转换工具
- 计算历史记录
- 多种界面主题

© 2025 401一组 版权所有
        """
        messagebox.showinfo("关于", about_info)
    
    def open_settings_dialog(self):
        """打开设置对话框"""
        settings_window = tk.Toplevel(self.root)
        settings_window.title("偏好设置")
        settings_window.geometry("400x350")
        settings_window.resizable(False, False)
        settings_window.transient(self.root)
        settings_window.grab_set()
        
        # 设置内容框架
        main_frame = ttk.Frame(settings_window, padding="20")
        main_frame.pack(fill='both', expand=True)
        
        # 计算设置
        calc_frame = ttk.LabelFrame(main_frame, text="计算设置", padding="10")
        calc_frame.pack(fill='x', pady=5)
        
        ttk.Label(calc_frame, text="小数位数:").grid(row=0, column=0, sticky='w')
        decimal_var = tk.StringVar(value=str(self.config.get('calculator.decimal_places', 6)))
        decimal_spin = ttk.Spinbox(calc_frame, from_=0, to=15, textvariable=decimal_var, width=10)
        decimal_spin.grid(row=0, column=1, sticky='e', padx=5)
        
        ttk.Label(calc_frame, text="角度单位:").grid(row=1, column=0, sticky='w')
        angle_var = tk.StringVar(value=self.config.get('calculator.angle_unit', 'degrees'))
        angle_combo = ttk.Combobox(calc_frame, textvariable=angle_var, 
                                  values=['degrees', 'radians'], state='readonly', width=10)
        angle_combo.grid(row=1, column=1, sticky='e', padx=5)
        
        # 界面设置
        ui_frame = ttk.LabelFrame(main_frame, text="界面设置", padding="10")
        ui_frame.pack(fill='x', pady=10)
        
        ttk.Label(ui_frame, text="默认标签页:").grid(row=0, column=0, sticky='w')
        default_tab_var = tk.StringVar(value=self.config.get('ui.default_tab', '0'))
        tab_combo = ttk.Combobox(ui_frame, textvariable=default_tab_var,
                                values=['基础计算', '科学计算', '转换器'], state='readonly', width=10)
        tab_combo.grid(row=0, column=1, sticky='e', padx=5)
        
        # 按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', pady=20)
        
        def save_settings():
            try:
                self.config.set('calculator.decimal_places', int(decimal_var.get()))
                self.config.set('calculator.angle_unit', angle_var.get())
                self.config.set('ui.default_tab', default_tab_var.get())
                settings_window.destroy()
                messagebox.showinfo("成功", "设置已保存，部分设置需要重启应用生效")
            except ValueError:
                messagebox.showerror("错误", "请输入有效的数值")
                
        ttk.Button(button_frame, text="保存", command=save_settings).pack(side='right', padx=5)
        ttk.Button(button_frame, text="取消", command=settings_window.destroy).pack(side='right')
        
        settings_window.columnconfigure(0, weight=1)
    
    def open_history_dialog(self):
        """打开历史记录对话框"""
        history_window = tk.Toplevel(self.root)
        history_window.title("计算历史")
        history_window.geometry("500x400")
        history_window.transient(self.root)
        
        main_frame = ttk.Frame(history_window, padding="10")
        main_frame.pack(fill='both', expand=True)
        
        # 历史记录列表
        history_listbox = tk.Listbox(main_frame, font=('Arial', 11))
        history_listbox.pack(fill='both', expand=True, pady=5)
        
        # 添加历史记录
        history = self.history_manager.get_history()
        for i, item in enumerate(history[-50:]):  # 显示最近50条记录
            history_listbox.insert(tk.END, f"{i+1}. {item}")
        
        # 按钮框架
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', pady=10)
        
        ttk.Button(button_frame, text="清空历史", command=self.clear_history).pack(side='left', padx=5)
        ttk.Button(button_frame, text="导出...", command=self.save_history).pack(side='left', padx=5)
        ttk.Button(button_frame, text="关闭", command=history_window.destroy).pack(side='right', padx=5)
    
    def on_closing(self):
        """窗口关闭事件处理:cite[7]"""
        # 保存窗口状态
        self.config.set('window.maximized', self.root.state() == 'zoomed')
        
        # 保存配置
        self.config.save_config()
        
        # 确认退出
        if messagebox.askokcancel("退出", "确定要退出计算器吗？"):
            self.root.destroy()

def main():
    """主函数:cite[7]"""
    root = tk.Tk()
    app = CalculatorMainWindow(root)
    root.mainloop()

if __name__ == "__main__":
    main()