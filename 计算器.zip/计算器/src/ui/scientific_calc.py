"""
修复版科学计算器界面
解决阶乘、开平方、log函数错误问题
"""

import tkinter as tk
from tkinter import ttk, messagebox
import math
import re
from src.advanced.scientific_calculator import ScientificCalculator

class ScientificCalculatorUI:
    """修复版科学计算器界面类"""
    
    def __init__(self, parent, main_app):
        self.parent = parent
        self.main_app = main_app
        self.calculator = ScientificCalculator()
        
        # 添加状态变量 - 修复缺失的属性
        self.logx_waiting_for_base = False
        self.logx_value = None
        
        self.setup_styles()
        self.setup_ui()
    
    def setup_styles(self):
        """设置界面样式"""
        style = ttk.Style()
        style.configure('Sci.TButton', font=('Arial', 10), padding=(8, 6))
        style.configure('Func.TButton', font=('Arial', 9, 'bold'), background='#e1f5fe', padding=(6, 4))
        style.configure('Accent.TButton', font=('Arial', 10, 'bold'), background='#0078d4', foreground='white', padding=(10, 8))
    
    def setup_ui(self):
        """设置界面"""
        main_frame = ttk.Frame(self.parent)
        main_frame.pack(fill='both', expand=True, padx=15, pady=15)
        
        self.setup_mode_selector(main_frame)
        self.setup_display(main_frame)
        self.setup_function_buttons(main_frame)
        self.setup_basic_operations(main_frame)
    
    def setup_mode_selector(self, parent):
        """设置模式选择区域"""
        mode_frame = ttk.LabelFrame(parent, text="计算模式", padding="10")
        mode_frame.pack(fill='x', pady=(0, 10))
        
        mode_inner_frame = ttk.Frame(mode_frame)
        mode_inner_frame.pack(fill='x')
        
        self.angle_mode = tk.StringVar(value="degrees")
        
        ttk.Radiobutton(mode_inner_frame, text="角度制", 
                       variable=self.angle_mode, value="degrees",
                       command=self.on_mode_change).pack(side='left', padx=10)
        ttk.Radiobutton(mode_inner_frame, text="弧度制", 
                       variable=self.angle_mode, value="radians",
                       command=self.on_mode_change).pack(side='left', padx=10)
        
        self.mode_label = ttk.Label(mode_inner_frame, text="当前: 角度制", 
                                   font=('Arial', 9), foreground='#666')
        self.mode_label.pack(side='right', padx=10)
    
    def setup_display(self, parent):
        """设置显示区域"""
        display_frame = ttk.LabelFrame(parent, text="输入/输出", padding="10")
        display_frame.pack(fill='x', pady=(0, 10))
        
        self.history_var = tk.StringVar()
        history_label = ttk.Label(display_frame, textvariable=self.history_var,
                                 font=('Arial', 9), foreground='#888')
        history_label.pack(anchor='e')
        
        self.display_var = tk.StringVar(value="0")
        self.display = ttk.Entry(
            display_frame,
            textvariable=self.display_var,
            font=('Arial', 18, 'bold'),
            justify='right',
            state='readonly',
            background='#f8f9fa'
        )
        self.display.pack(fill='x', ipady=12, pady=(5, 0))
        
        self.display.bind('<Key>', self.on_key_press)
    
    def setup_function_buttons(self, parent):
        """设置函数按钮区域 - 修复版本"""
        func_frame = ttk.LabelFrame(parent, text="科学函数", padding="10")
        func_frame.pack(fill='x', pady=(0, 10))
        
        # 第一行：三角函数
        trig_frame = ttk.Frame(func_frame)
        trig_frame.pack(fill='x', pady=5)
        ttk.Label(trig_frame, text="三角函数:", font=('Arial', 9, 'bold')).pack(side='left', padx=(0, 10))
        
        trig_buttons = [
            ('sin', 'sin('), ('cos', 'cos('), ('tan', 'tan('), 
            ('π', 'π'), ('e', 'e')
        ]
        for text, func in trig_buttons:
            btn = ttk.Button(trig_frame, text=text, 
                        command=lambda f=func: self.insert_function(f), 
                        style='Func.TButton')
            btn.pack(side='left', padx=2)
        
        # 第二行：数学函数
        math_frame = ttk.Frame(func_frame)
        math_frame.pack(fill='x', pady=5)
        ttk.Label(math_frame, text="数学函数:", font=('Arial', 9, 'bold')).pack(side='left', padx=(0, 10))
        
        math_buttons = [
            ('x²', '²'), ('x³', '³'), ('√', '√('), ('³√', '³√('),
            ('log₁₀', 'log('), ('ln', 'ln('), ('logₓ', 'logx'), ('x^y', '^')
        ]
        for text, func in math_buttons:
            btn = ttk.Button(math_frame, text=text,
                        command=lambda f=func: self.insert_function(f),
                        style='Func.TButton')
            btn.pack(side='left', padx=2)
        
        # 第三行：高级函数
        adv_frame = ttk.Frame(func_frame)
        adv_frame.pack(fill='x', pady=5)
        ttk.Label(adv_frame, text="高级函数:", font=('Arial', 9, 'bold')).pack(side='left', padx=(0, 10))
        
        adv_buttons = [
            ('exp', 'exp('), ('n!', '!'), ('1/x', '⁻¹'), ('|x|', 'abs(')
        ]
        for text, func in adv_buttons:
            btn = ttk.Button(adv_frame, text=text,
                        command=lambda f=func: self.insert_function(f),
                        style='Func.TButton')
            btn.pack(side='left', padx=2)
    
    def setup_basic_operations(self, parent):
        """设置基础操作区域"""
        basic_frame = ttk.LabelFrame(parent, text="基础操作", padding="10")
        basic_frame.pack(fill='both', expand=True)
        
        for i in range(5):
            basic_frame.grid_rowconfigure(i, weight=1)
        for i in range(5):
            basic_frame.grid_columnconfigure(i, weight=1)
        
        buttons = [
            ['(', ')', '⌫', 'C', '±'],
            ['7', '8', '9', '/', '%'],
            ['4', '5', '6', '*', '²'],
            ['1', '2', '3', '-', '√'],
            ['0', '.', '=', '+', 'π']
        ]
        
        for i, row in enumerate(buttons):
            for j, text in enumerate(row):
                if text == '=':
                    btn = ttk.Button(basic_frame, text=text, command=self.calculate_result, style='Accent.TButton')
                elif text in ['C', '⌫']:
                    btn = ttk.Button(basic_frame, text=text, command=lambda t=text: self.on_special_button(t), style='Sci.TButton')
                else:
                    btn = ttk.Button(basic_frame, text=text, command=lambda t=text: self.on_button_click(t), style='Sci.TButton')
                btn.grid(row=i, column=j, sticky='nsew', padx=2, pady=2)
    
    def on_mode_change(self):
        """角度/弧度模式切换"""
        mode = self.angle_mode.get()
        self.calculator.set_angle_mode(mode)
        self.mode_label.config(text=f"当前: {'角度制' if mode == 'degrees' else '弧度制'}")
    
    def insert_function(self, func):
        """插入函数到显示框 - 修复版本"""
        current_text = self.display_var.get()
        
        # 处理特殊函数符号
        replacements = {
            '²': '²',
            '³': '³', 
            '⁻¹': '⁻¹',
            '^': '^',
            'π': 'π',
            'e': 'e'
        }
        
        if func in replacements:
            display_func = replacements[func]
            actual_func = {
                '²': '**2',
                '³': '**3', 
                '⁻¹': '**(-1)',
                '^': '**',
                'π': 'pi',
                'e': 'e'
            }[func]
        else:
            display_func = func
            actual_func = func
        
        # 特殊处理 logx 按钮
        if func == 'logx':
            if current_text == "0":
                # 如果当前是0，直接开始输入logx
                self.display_var.set("logx(")
                self.logx_waiting_for_base = True
            else:
                # 将当前内容作为真数，然后添加logx(
                # 检查当前文本是否以数字或右括号结尾
                if current_text and (current_text[-1].isdigit() or current_text[-1] == ')' or current_text[-1] == 'π' or current_text[-1] == 'e'):
                    self.display_var.set(current_text + " logx(")
                    self.logx_waiting_for_base = True
                else:
                    self.display_var.set(current_text + "logx(")
                    self.logx_waiting_for_base = True
            return
        
        # 对于需要参数的函数，自动添加左括号
        if func in ['sin(', 'cos(', 'tan(', '√(', '³√(', 'log(', 'ln(', 'exp(', 'abs(']:
            if current_text == "0":
                self.display_var.set(display_func)
            else:
                # 检查当前文本是否以数字或右括号结尾，如果是，则添加乘号
                if current_text and (current_text[-1].isdigit() or current_text[-1] == ')'):
                    self.display_var.set(current_text + '*' + display_func)
                else:
                    self.display_var.set(current_text + display_func)
        elif func == '!':  # 阶乘特殊处理
            if current_text == "0":
                self.display_var.set("0")
            else:
                self.display_var.set(current_text + '!')
        else:
            if current_text == "0":
                self.display_var.set(display_func)
            else:
                self.display_var.set(current_text + display_func)
    
    def on_button_click(self, button_text):
        """处理按钮点击"""
        current_text = self.display_var.get()
        
        # 如果正在等待logx的底数，并且用户输入了数字或π/e
        if (self.logx_waiting_for_base and 
            (button_text.isdigit() or button_text in ['.', 'π', 'e'])):
            
            # 如果当前是"logx("，直接替换
            if current_text.endswith("logx("):
                self.display_var.set(current_text + button_text)
            else:
                # 否则正常添加
                if current_text == "0":
                    self.display_var.set(button_text)
                else:
                    self.display_var.set(current_text + button_text)
        else:
            if current_text == "0":
                self.display_var.set(button_text)
            else:
                self.display_var.set(current_text + button_text)
    
    def on_special_button(self, button_text):
        """处理特殊按钮"""
        current_text = self.display_var.get()
        
        if button_text == 'C':
            self.display_var.set("0")
            self.history_var.set("")
            self.logx_waiting_for_base = False
            self.logx_value = None
        elif button_text == '⌫':
            if current_text == "0" or len(current_text) == 1:
                self.display_var.set("0")
                self.logx_waiting_for_base = False
            else:
                self.display_var.set(current_text[:-1])
                # 如果删除了logx(，重置状态
                if not current_text.endswith("logx("):
                    self.logx_waiting_for_base = False
        elif button_text == '±':
            if current_text.startswith('-'):
                self.display_var.set(current_text[1:])
            else:
                self.display_var.set('-' + current_text)
        # 处理右括号，特别是logx的情况
        elif button_text == ')':
            if self.logx_waiting_for_base and current_text.endswith("logx("):
                # 如果logx(后面没有内容，添加1作为默认底数
                self.display_var.set(current_text + "1)")
                self.logx_waiting_for_base = False
            else:
                if current_text == "0":
                    self.display_var.set("0")
                else:
                    self.display_var.set(current_text + ")")
                    # 如果添加了右括号且之前正在等待logx的底数，重置状态
                    if self.logx_waiting_for_base:
                        self.logx_waiting_for_base = False
    
    def on_key_press(self, event):
        """处理键盘输入"""
        if event.char in '0123456789+-*/.()':
            self.on_button_click(event.char)
        elif event.keysym == 'Return':
            self.calculate_result()
        elif event.keysym == 'BackSpace':
            self.on_special_button('⌫')
        elif event.keysym == 'Escape':
            self.on_special_button('C')
        return "break"
    
    def calculate_result(self):
        """计算结果 - 修复版本"""
        try:
            expression = self.display_var.get()
            
            if not expression or expression == "0":
                return
            
            print(f"计算表达式: {expression}")  # 调试输出
            
            # 预处理表达式
            expression = self.preprocess_expression(expression)
            print(f"预处理后: {expression}")  # 调试输出
            
            # 安全计算
            result = self.safe_evaluate(expression)
            
            # 更新显示
            self.display_var.set(str(result))
            self.history_var.set(f"{expression} =")
            
            # 重置logx状态
            self.logx_waiting_for_base = False
            self.logx_value = None
            
            # 添加到历史记录
            self.calculator.add_to_history(expression, str(result))
            if hasattr(self.main_app, 'history_manager'):
                self.main_app.history_manager.add_entry(expression, str(result))
            
            print(f"计算结果: {result}")  # 调试输出
            
        except Exception as e:
            error_msg = f"计算错误: {str(e)}"
            self.display_var.set("错误")
            self.history_var.set(error_msg)
            print(f"❌ {error_msg}")  # 调试输出
            if hasattr(self.main_app, 'status_var'):
                self.main_app.status_var.set(error_msg)
    
    def preprocess_expression(self, expression):
        """预处理表达式 - 完全重写版本"""
        print(f"原始表达式: {expression}")  # 调试输出
        
        # 第一步：处理特殊函数符号（先处理复合符号）
        import re
        
        # 处理³√(x) -> cbrt(x) - 这个必须在最前面处理
        expression = re.sub(r'³√\(', 'cbrt(', expression)
        
        # 处理√(x) -> sqrt(x)
        expression = re.sub(r'√\(', 'sqrt(', expression)
        
        # 第二步：替换幂运算符号
        replacements = {
            '²': '**2',
            '³': '**3', 
            '⁻¹': '**(-1)',
            '^': '**'
        }
        
        for old, new in replacements.items():
            expression = expression.replace(old, new)
        
        print(f"替换符号后: {expression}")  # 调试输出
        
        # 第三步：处理数学常量
        # 使用正则表达式确保只替换独立的π和e，而不是函数名中的
        expression = re.sub(r'(?<![a-zA-Z_])π(?![a-zA-Z_])', 'pi', expression)
        expression = re.sub(r'(?<![a-zA-Z_])e(?![a-zA-Z_])', 'e', expression)
        
        print(f"处理常量后: {expression}")  # 调试输出
        
        # 第四步：处理新的logx格式：值 logx(底数)
        def replace_logx(match):
            value_expr = match.group(1).strip()
            base_expr = match.group(2).strip()
            return f'custom_log({value_expr}, {base_expr})'
        
        # 匹配格式：值 logx(底数) - 改进正则表达式
        # 使用更宽松的匹配，允许更复杂的表达式
        expression = re.sub(r'([^\)]+?)\s*logx\(([^)]+)\)', replace_logx, expression)
        
        print(f"处理logx后: {expression}")  # 调试输出
        
        # 第五步：处理阶乘符号 !
        # 将 n! 替换为 factorial(n)
        def replace_factorial(match):
            # 提取阶乘前面的表达式
            expr = match.group(1)
            # 如果表达式包含运算符，需要加括号
            if any(op in expr for op in ['+', '-', '*', '/', '**']):
                return f'factorial({expr})'
            else:
                return f'factorial({expr})'
        
        # 匹配数字（包括小数）或右括号后跟!号
        expression = re.sub(r'(\d+(?:\.\d+)?|\))\!', replace_factorial, expression)
        
        print(f"处理阶乘后: {expression}")  # 调试输出
        
        # 第六步：修复可能的语法问题
        # 处理连续的**问题（如**3sqrt变成**3*sqrt）
        expression = re.sub(r'(\*\*)([a-zA-Z])', r'\1*\2', expression)
        
        # 处理数字后跟函数的情况（如8sqrt变成8*sqrt）
        expression = re.sub(r'(\d)([a-zA-Z\(])', r'\1*\2', expression)
        
        # 处理右括号后跟函数的情况（如)sqrt变成)*sqrt）
        expression = re.sub(r'(\))([a-zA-Z\(])', r'\1*\2', expression)
        
        print(f"最终表达式: {expression}")  # 调试输出
        
        return expression

    def safe_evaluate(self, expression):
        """安全计算表达式 - 修复版本"""
        import math
        
        # 自定义立方根函数
        def cbrt(x):
            return math.pow(x, 1/3)
        
        # 自定义任意底数对数函数
        def custom_log(value, base):
            if value <= 0:
                raise ValueError("对数的真数必须大于0")
            if base <= 0 or base == 1:
                raise ValueError("对数的底数必须大于0且不等于1")
            return math.log(value) / math.log(base)
        
        # 允许的函数和常量
        allowed_names = {
            'sin': math.sin,
            'cos': math.cos,
            'tan': math.tan,
            'sqrt': math.sqrt,
            'cbrt': cbrt,
            'log': math.log10,  # 以10为底
            'ln': math.log,     # 以e为底
            'custom_log': custom_log,  # 任意底数
            'exp': math.exp,
            'abs': abs,
            'factorial': math.factorial,
            'pi': math.pi,
            'e': math.e
        }
        
        try:
            # 安全检查
            if not self.is_safe_expression(expression):
                raise ValueError("表达式包含不安全字符")
            
            print(f"最终计算表达式: {expression}")  # 调试输出
            
            # 使用eval但限制可用的函数
            result = eval(expression, {"__builtins__": {}}, allowed_names)
            
            # 处理特殊情况
            if math.isnan(result) or math.isinf(result):
                raise ValueError("计算结果无效")
                
            return round(float(result), 10)  # 限制小数位数
            
        except Exception as e:
            # 提供更具体的错误信息
            error_msg = str(e)
            print(f"计算异常: {error_msg}")  # 调试输出
            
            if "factorial" in error_msg and ("negative" in error_msg or "integer" in error_msg):
                raise ValueError("阶乘只能计算非负整数")
            elif "sqrt" in error_msg and "negative" in error_msg:
                raise ValueError("不能计算负数的平方根")
            elif "log" in error_msg and ("negative" in error_msg or "zero" in error_msg):
                if "base" in error_msg:
                    raise ValueError("对数的底数必须大于0且不等于1")
                else:
                    raise ValueError("对数的真数必须大于0")
            elif "invalid syntax" in error_msg.lower():
                raise ValueError("表达式语法错误")
            else:
                raise ValueError(f"表达式计算错误: {error_msg}")

    def is_safe_expression(self, expression):
        """检查表达式安全性 - 修复版本"""
        import string
        
        # 允许的字符（包括阶乘符号!和下划线_）
        allowed_chars = set('0123456789+-*/.() []{},:e! _')
        allowed_chars.update(string.ascii_letters)  # 允许字母用于函数名
        
        # 检查每个字符
        for char in expression:
            if char not in allowed_chars:
                print(f"发现不安全字符: '{char}'")  # 调试输出
                return False
        
        # 不允许的危险模式
        dangerous_patterns = [
            '__', 'import', 'exec', 'eval', 'open', 'file',
            'os.', 'sys.', 'subprocess', 'compile'
        ]
        
        for pattern in dangerous_patterns:
            if pattern in expression.lower():
                print(f"发现危险模式: {pattern}")  # 调试输出
                return False
        
        return True