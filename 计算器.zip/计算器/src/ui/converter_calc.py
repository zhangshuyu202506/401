"""
转换器界面
包含进制转换和单位转换
开发者：张书宇
"""

import tkinter as tk
from tkinter import ttk, messagebox
from src.advanced.base_converter import BaseConverter
from src.advanced.unit_converter import UnitConverter

class ConverterCalculatorUI:
    """转换器界面类"""
    
    def __init__(self, parent, main_app):
        self.parent = parent
        self.main_app = main_app
        self.base_converter = BaseConverter()
        self.unit_converter = UnitConverter()
        
        self.setup_ui()
    
    def setup_ui(self):
        """设置转换器界面"""
        # 创建标签页
        self.notebook = ttk.Notebook(self.parent)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # 进制转换标签页
        self.base_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.base_frame, text="进制转换")
        self.setup_base_converter()
        
        # 单位转换标签页
        self.unit_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.unit_frame, text="单位转换")
        self.setup_unit_converter()
    
    def setup_base_converter(self):
        """设置进制转换界面"""
        frame = self.base_frame
        
        # 输入区域
        input_frame = ttk.LabelFrame(frame, text="输入设置")
        input_frame.pack(fill='x', pady=5, padx=10)
        
        # 数值输入
        ttk.Label(input_frame, text="输入数值:", font=('Arial', 10)).grid(
            row=0, column=0, padx=5, pady=5, sticky='e'
        )
        self.base_input = ttk.Entry(input_frame, font=('Arial', 12))
        self.base_input.grid(row=0, column=1, padx=5, pady=5, sticky='ew')
        self.base_input.bind('<KeyRelease>', self.on_base_input_change)
        
        # 原进制选择
        ttk.Label(input_frame, text="原进制:", font=('Arial', 10)).grid(
            row=1, column=0, padx=5, pady=5, sticky='e'
        )
        self.from_base = ttk.Combobox(
            input_frame, 
            values=['二进制', '八进制', '十进制', '十六进制'], 
            state='readonly',
            font=('Arial', 10)
        )
        self.from_base.set('十进制')
        self.from_base.grid(row=1, column=1, padx=5, pady=5, sticky='ew')
        self.from_base.bind('<<ComboboxSelected>>', self.on_base_input_change)
        
        # 快速转换按钮
        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=2, column=0, columnspan=2, pady=10)
        
        quick_buttons = [
            ('转二进制', self.convert_to_binary),
            ('转八进制', self.convert_to_octal),
            ('转十进制', self.convert_to_decimal),
            ('转十六进制', self.convert_to_hex)
        ]
        
        for i, (text, command) in enumerate(quick_buttons):
            btn = ttk.Button(button_frame, text=text, command=command)
            btn.grid(row=0, column=i, padx=2, sticky='ew')
            button_frame.columnconfigure(i, weight=1)
        
        # 结果显示区域
        result_frame = ttk.LabelFrame(frame, text="转换结果")
        result_frame.pack(fill='both', expand=True, pady=5, padx=10)
        
        # 创建文本区域和滚动条
        text_frame = ttk.Frame(result_frame)
        text_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        self.base_results = tk.Text(
            text_frame, 
            height=12, 
            font=('Consolas', 11),
            wrap=tk.WORD,
            state='disabled'
        )
        
        scrollbar = ttk.Scrollbar(text_frame, command=self.base_results.yview)
        self.base_results.configure(yscrollcommand=scrollbar.set)
        
        self.base_results.pack(side='left', fill='both', expand=True)
        scrollbar.pack(side='right', fill='y')
        
        # 配置网格权重
        input_frame.columnconfigure(1, weight=1)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(1, weight=1)
    
    def setup_unit_converter(self):
        """设置单位转换界面"""
        frame = self.unit_frame
        
        # 类别选择
        category_frame = ttk.LabelFrame(frame, text="转换类别")
        category_frame.pack(fill='x', pady=5, padx=10)
        
        self.unit_category = ttk.Combobox(
            category_frame, 
            values=['长度', '重量', '温度', '面积', '体积', '速度'],
            state='readonly',
            font=('Arial', 10)
        )
        self.unit_category.set('长度')
        self.unit_category.bind('<<ComboboxSelected>>', self.on_category_change)
        self.unit_category.pack(pady=10, padx=10, fill='x')
        
        # 转换区域
        convert_frame = ttk.LabelFrame(frame, text="单位转换")
        convert_frame.pack(fill='x', pady=5, padx=10)
        
        # 输入行
        input_row = ttk.Frame(convert_frame)
        input_row.pack(fill='x', pady=10, padx=10)
        
        self.unit_input = ttk.Entry(input_row, font=('Arial', 12), width=15)
        self.unit_input.pack(side='left', padx=5)
        
        self.from_unit = ttk.Combobox(input_row, state='readonly', width=12, font=('Arial', 10))
        self.from_unit.pack(side='left', padx=5)
        
        ttk.Label(input_row, text="→", font=('Arial', 14)).pack(side='left', padx=10)
        
        self.to_unit = ttk.Combobox(input_row, state='readonly', width=12, font=('Arial', 10))
        self.to_unit.pack(side='left', padx=5)
        
        # 转换按钮和结果
        result_frame = ttk.Frame(convert_frame)
        result_frame.pack(fill='x', pady=10)
        
        self.unit_result = ttk.Label(
            result_frame, 
            text="结果将显示在这里", 
            font=('Arial', 14, 'bold'), 
            foreground='blue'
        )
        self.unit_result.pack(pady=5)
        
        convert_btn = ttk.Button(
            result_frame, 
            text="转换", 
            command=self.convert_units,
            style='Accent.TButton'
        )
        convert_btn.pack(pady=5)
        
        # 交换单位按钮
        swap_btn = ttk.Button(
            result_frame, 
            text="↔ 交换单位", 
            command=self.swap_units
        )
        swap_btn.pack(pady=5)
        
        # 初始化单位列表
        self.on_category_change()
    
    def on_base_input_change(self, event=None):
        """当进制输入改变时自动转换"""
        self.convert_base()
    
    def on_category_change(self, event=None):
        """类别改变时更新单位列表"""
        category = self.unit_category.get()
        
        # 获取该类别下的所有单位
        units = self.unit_converter.get_available_units(category)
        display_units = [self.unit_converter.get_display_name(unit) for unit in units]
        
        self.from_unit['values'] = display_units
        self.to_unit['values'] = display_units
        
        if display_units:
            self.from_unit.set(display_units[0])
            if len(display_units) > 1:
                self.to_unit.set(display_units[1])
            else:
                self.to_unit.set(display_units[0])
    def convert_base(self):
        """执行进制转换 - 添加历史记录"""
        try:
            value = self.base_input.get().strip()
            from_base_display = self.from_base.get()
        
            if not value:
                self.show_base_results("请输入要转换的数值")
                return
        
            # 将显示名称转换为内部键值
            from_base = self.base_converter.get_base_key_from_display_name(from_base_display)
        
            # 验证输入
            if not self.base_converter.validate_input(value.upper(), from_base):
                self.show_base_results(f"错误: 无效的{from_base_display}数值")
                return
        
            # 获取所有转换结果
            results = self.base_converter.get_all_conversions(value, from_base)
         
            # 格式化显示结果
            result_text = f"原始数值: {value} ({from_base_display})\n"
            result_text += "=" * 40 + "\n\n"
        
            for base_key, result in results.items():
                display_name = self.base_converter.get_base_display_name(base_key)
            
                # 对二进制结果进行格式化（添加空格分隔）
                if base_key == 'binary' and result != "无效输入":
                    formatted_binary = self.base_converter.format_binary_with_spaces(result)
                    result_text += f"{display_name}: {formatted_binary}\n"
                else:
                    result_text += f"{display_name}: {result}\n"
        
            self.show_base_results(result_text)
        
            # ✅ 修复：添加到历史记录
            history_entry = f"进制转换: {value} ({from_base_display})"
            self.main_app.history_manager.add_entry(history_entry, "查看转换结果")
            self.main_app.status_var.set("进制转换完成")
        
        except Exception as e:
            self.show_base_results(f"错误: {str(e)}")
            self.main_app.status_var.set(f"进制转换错误: {str(e)}")

    
    def show_base_results(self, text):
        """显示进制转换结果"""
        self.base_results.config(state='normal')
        self.base_results.delete(1.0, tk.END)
        self.base_results.insert(tk.END, text)
        self.base_results.config(state='disabled')
    
    def convert_to_binary(self):
        """快速转换为二进制"""
        self.convert_to_specific_base('binary')
    
    def convert_to_octal(self):
        """快速转换为八进制"""
        self.convert_to_specific_base('octal')
    
    def convert_to_decimal(self):
        """快速转换为十进制"""
        self.convert_to_specific_base('decimal')
    
    def convert_to_hex(self):
        """快速转换为十六进制"""
        self.convert_to_specific_base('hexadecimal')
    
    def convert_to_specific_base(self, target_base):
        """转换为特定进制"""
        try:
            value = self.base_input.get().strip()
            from_base_display = self.from_base.get()
            
            if not value:
                messagebox.showwarning("输入错误", "请输入要转换的数值")
                return
            
            from_base = self.base_converter.get_base_key_from_display_name(from_base_display)
            
            if not self.base_converter.validate_input(value.upper(), from_base):
                messagebox.showerror("输入错误", f"无效的{from_base_display}数值")
                return
            
            result = self.base_converter.convert(value, from_base, target_base)
            target_display = self.base_converter.get_base_display_name(target_base)
            
            # 对二进制结果进行格式化
            if target_base == 'binary':
                result = self.base_converter.format_binary_with_spaces(result)
            
            messagebox.showinfo(
                "转换结果", 
                f"{value} ({from_base_display}) = {result} ({target_display})"
            )
            
            # 添加到历史记录
            self.main_app.history.append(
                f"进制转换: {value} ({from_base_display}) → {result} ({target_display})"
            )
            
        except Exception as e:
            messagebox.showerror("转换错误", str(e))
    
    def convert_units(self):
        
        """执行单位转换 - 添加历史记录"""
        try:
            value_text = self.unit_input.get().strip()
            if not value_text:
                self.unit_result.config(text="请输入数值", foreground='red')
                return
            
            value = float(value_text)
            category = self.unit_category.get()
            from_unit_display = self.from_unit.get()
            to_unit_display = self.to_unit.get()
            
            if from_unit_display == to_unit_display:
                result_text = f"{value} {from_unit_display}"
                self.unit_result.config(text=result_text, foreground='blue')
                return
            
            # 执行转换
            result = self.unit_converter.convert(value, category, from_unit_display, to_unit_display)
            
            # 显示结果
            result_text = f"{result:.6f} {to_unit_display}"
            self.unit_result.config(text=result_text, foreground='blue')
            
            # ✅ 修复：添加到历史记录
            history_entry = f"{value} {from_unit_display} = {result:.4f} {to_unit_display}"
            self.main_app.history_manager.add_entry(
                f"单位转换({category})", 
                history_entry
            )
            self.main_app.status_var.set("单位转换完成")
            
        except ValueError:
            self.unit_result.config(text="请输入有效的数字", foreground='red')
            self.main_app.status_var.set("输入错误: 请输入有效数字")
        except Exception as e:
            error_msg = f"错误: {str(e)}"
            self.unit_result.config(text=error_msg, foreground='red')
            self.main_app.status_var.set(f"单位转换错误: {str(e)}")
        
    def swap_units(self):
        """交换源单位和目标单位"""
        current_from = self.from_unit.get()
        current_to = self.to_unit.get()
        
        self.from_unit.set(current_to)
        self.to_unit.set(current_from)
        
        # 如果已经有输入值，自动重新计算
        if self.unit_input.get().strip():
            self.convert_units()