def __init__(self, parent, main_app):
    self.parent = parent
    self.main_app = main_app
    self.calculator = ScientificCalculator()
    
    # 添加状态变量 - 修复缺失的属性
    self.logx_waiting_for_base = False
    self.logx_value = None
    
    self.setup_styles()
    self.setup_ui()