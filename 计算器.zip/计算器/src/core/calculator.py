"""
计算器核心引擎
处理数学表达式计算
"""

import math
import re

class CalculatorEngine:
    """计算器引擎类"""
    
    def __init__(self):
        self.functions = {
            'sin': math.sin,
            'cos': math.cos,
            'tan': math.tan,
            'log': math.log10,
            'ln': math.log,
            'sqrt': math.sqrt,
            'exp': math.exp,
            'abs': abs,
            'pi': math.pi,
            'e': math.e
        }
        
    def evaluate(self, expression: str) -> float:
        """
        计算数学表达式
        
        Args:
            expression: 数学表达式字符串
            
        Returns:
            计算结果
            
        Raises:
            ValueError: 表达式格式错误
            ZeroDivisionError: 除零错误
        """
        # 预处理表达式
        expression = self.preprocess_expression(expression)
        
        # 安全性检查
        if not self.is_safe_expression(expression):
            raise ValueError("表达式包含不安全字符")
            
        try:
            # 替换数学函数和常量
            for func_name, func in self.functions.items():
                if func_name in ['pi', 'e']:
                    expression = expression.replace(func_name, str(func))
                else:
                    # 简单的函数调用替换
                    pattern = f'{func_name}\(([^)]+)\)'
                    while re.search(pattern, expression):
                        expression = re.sub(pattern, 
                                          lambda m: str(func(self.evaluate_simple(m.group(1)))), 
                                          expression)
            
            # 计算表达式
            result = eval(expression, {'__builtins__': None}, {})
            return float(result)
            
        except ZeroDivisionError:
            raise ZeroDivisionError("除零错误")
        except Exception as e:
            raise ValueError(f"表达式计算错误: {str(e)}")
            
    def preprocess_expression(self, expression: str) -> str:
        """预处理表达式"""
        # 移除空格
        expression = expression.replace(' ', '')
        
        # 处理隐式乘法，如 2(3+4) -> 2*(3+4)
        expression = re.sub(r'(\d)(\()', r'\1*\2', expression)
        expression = re.sub(r'(\))(\d)', r'\1*\2', expression)
        expression = re.sub(r'(\))(\()', r'\1*\2', expression)
        
        return expression
        
    def evaluate_simple(self, simple_expr: str) -> float:
        """计算简单表达式（用于函数参数）"""
        try:
            return float(eval(simple_expr, {'__builtins__': None}, {}))
        except:
            raise ValueError(f"函数参数计算错误: {simple_expr}")
            
    def is_safe_expression(self, expression: str) -> bool:
        """检查表达式是否安全"""
        # 允许的字符
        allowed_chars = set('0123456789+-*/.()e ')
        allowed_chars.update(self.functions.keys())
        
        # 检查每个字符
        for char in expression:
            if char not in allowed_chars and not char.isalpha():
                return False
                
        # 检查函数调用格式
        for func in self.functions:
            if func in expression and f'{func}(' not in expression:
                return False
                
        return True