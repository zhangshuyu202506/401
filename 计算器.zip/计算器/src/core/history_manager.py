"""
历史记录管理模块
负责计算历史的存储和管理
"""

import json
import os
from datetime import datetime

class HistoryManager:
    """历史记录管理器"""
    
    def __init__(self, max_entries=100):
        self.max_entries = max_entries
        self.history = []
    
    def add_entry(self, expression: str, result: str):
        """添加历史记录条目"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = {
            "timestamp": timestamp,
            "expression": expression,
            "result": result
        }
        
        self.history.append(entry)
        
        # 限制历史记录数量
        if len(self.history) > self.max_entries:
            self.history.pop(0)
    
    def get_history(self):
        """获取历史记录"""
        return self.history.copy()
    
    def clear_history(self):
        """清空历史记录"""
        self.history.clear()
    
    def save_to_file(self, filename: str):
        """保存历史记录到文件"""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump({
                    "max_entries": self.max_entries,
                    "history": self.history
                }, f, ensure_ascii=False, indent=2)
        except Exception as e:
            raise Exception(f"保存历史记录失败: {e}")
    
    def load_from_file(self, filename: str):
        """从文件加载历史记录"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.history = data.get("history", [])
                self.max_entries = data.get("max_entries", 100)
        except Exception as e:
            raise Exception(f"加载历史记录失败: {e}")