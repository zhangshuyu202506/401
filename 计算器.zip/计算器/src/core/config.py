"""
配置管理模块
负责应用设置和用户偏好
"""

import json
import os
from typing import Dict, Any

class AppConfig:
    """应用配置类"""
    
    def __init__(self, config_file: str = "calculator_config.json"):
        self.config_file = config_file
        self.default_config = {
            "window": {
                "width": 800,
                "height": 650,
                "maximized": False,
                "theme": "light"
            },
            "calculator": {
                "decimal_places": 6,
                "angle_unit": "degrees",
                "number_format": "normal"
            },
            "history": {
                "max_entries": 100,
                "auto_save": True
            },
            "ui": {
                "default_tab": "0"
            }
        }
        self.config = self.load_config()
    
    def load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception as e:
            print(f"加载配置失败: {e}")
        
        return self.default_config.copy()
    
    def save_config(self):
        """保存配置到文件"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存配置失败: {e}")
    
    def get(self, key: str, default=None):
        """获取配置值"""
        keys = key.split('.')
        value = self.config
        try:
            for k in keys:
                value = value[k]
            return value
        except (KeyError, TypeError):
            return default
    
    def set(self, key: str, value):
        """设置配置值"""
        keys = key.split('.')
        config = self.config
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        config[keys[-1]] = value
        self.save_config()