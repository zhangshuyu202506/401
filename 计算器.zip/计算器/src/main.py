"""
401一组计算器 - 主程序入口
桌面版多功能计算器应用程序
开发者：张书宇 & 李融璿
"""

import tkinter as tk
import sys
import os

# 添加src目录到Python路径，确保模块导入正常
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

def main():
    """主函数 - 程序入口点"""
    try:
        # 创建主窗口
        root = tk.Tk()
        
        # 导入并创建主应用
        from src.ui.main_window import CalculatorMainWindow
        app = CalculatorMainWindow(root)
        
        # 运行应用
        root.mainloop()
        
    except ImportError as e:
        print(f"模块导入错误: {e}")
        print("请确保所有必要的模块文件都存在")
        input("按回车键退出...")
    except Exception as e:
        print(f"程序启动错误: {e}")
        input("按回车键退出...")

if __name__ == "__main__":
    main()