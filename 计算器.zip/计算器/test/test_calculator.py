import pytest
import sys
import os

# 添加src到Python路径
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from core.calculator import CalculatorEngine

class TestCalculatorEngine:
    """计算器引擎测试类"""
    
    def setup_method(self):
        """每个测试方法前执行"""
        self.calc = CalculatorEngine()
    
    def test_addition(self):
        """测试加法"""
        assert self.calc.evaluate("2+3") == 5
        assert self.calc.evaluate("10+20") == 30
    
    def test_subtraction(self):
        """测试减法"""
        assert self.calc.evaluate("5-2") == 3
        assert self.calc.evaluate("10-20") == -10
    
    def test_multiplication(self):
        """测试乘法"""
        assert self.calc.evaluate("3*4") == 12
        assert self.calc.evaluate("2.5*4") == 10.0
    
    def test_division(self):
        """测试除法"""
        assert self.calc.evaluate("10/2") == 5
        assert self.calc.evaluate("7/2") == 3.5
    
    def test_division_by_zero(self):
        """测试除零错误"""
        with pytest.raises(ZeroDivisionError):
            self.calc.evaluate("5/0")
    
    def test_complex_expression(self):
        """测试复杂表达式"""
        assert self.calc.evaluate("2+3*4") == 14
        assert self.calc.evaluate("(2+3)*4") == 20
    
    def test_expression_safety(self):
        """测试表达式安全性"""
        # 安全表达式
        assert self.calc.is_safe_expression("2+3")
        assert self.calc.is_safe_expression("(5+3)*2")
        
        # 不安全表达式
        assert not self.calc.is_safe_expression("__import__('os')")
        assert not self.calc.is_safe_expression("2+3; import os")
    
    def test_history(self):
        """测试历史记录"""
        self.calc.evaluate("2+3")
        self.calc.evaluate("5*4")
        
        history = self.calc.get_history()
        assert len(history) == 2
        assert "2+3 = 5" in history
        assert "5*4 = 20" in history

if __name__ == "__main__":
    # 运行测试
    pytest.main([__file__])